/*
* Страница для отображения карты мира с маркером показывающим место съемки фотографии
* */

package ru.taximaster.testapp.activity;

import android.os.Bundle;
import android.support.v4.app.FragmentActivity;
import android.util.Log;

import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.MapStyleOptions;
import com.google.android.gms.maps.model.MarkerOptions;

import ru.taximaster.testapp.R;

public class GlobalMapActivity  extends FragmentActivity {

    static class Constants {
       final static String TAG = "GlobalMap";
    }

    private GoogleMap mMap;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.global_map);

        Bundle extras = getIntent().getExtras();

        if(extras !=null)
        {
            final int ind =  extras.getInt("ImageId");
            final LatLng coordinate = SearchActivity.coordinates[ind];

            SupportMapFragment mapFragment = (SupportMapFragment) getSupportFragmentManager()
                    .findFragmentById(R.id.map);
            mapFragment.getMapAsync(new OnMapReadyCallback() {

                @Override
                public void onMapReady(GoogleMap googleMap) {

                    mMap = googleMap;

                   mMap.setMapStyle( MapStyleOptions.loadRawResourceStyle(getBaseContext(), R.raw.map_style));
                   Log.d( Constants.TAG, coordinate.toString() );

                    mMap.addMarker(new MarkerOptions().position(coordinate)) ;
                    mMap.moveCamera(CameraUpdateFactory.newLatLng(coordinate));
                }
            });
        }
    }

}