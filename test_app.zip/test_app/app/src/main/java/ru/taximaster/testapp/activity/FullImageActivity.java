/*
* Страница для отображения фотографии на весь экран
* */

package ru.taximaster.testapp.activity;

import android.content.Intent;
import android.graphics.drawable.BitmapDrawable;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;

import ru.taximaster.testapp.R;

public class FullImageActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.full_image);


        Bundle extras = getIntent().getExtras();
        final int ind = extras.getInt("ImageId");

        ImageView v = (ImageView) findViewById(R.id.imageViewFull);
        BitmapDrawable b = SearchActivity.bitmaps[ind];
        if (b != null) {
            v.setImageDrawable(b);
        }

        Button button = (Button) findViewById(R.id.button_show_map);

        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

            Intent i = new Intent(getBaseContext(), GlobalMapActivity.class);
            i.putExtra("ImageId", ind);
            startActivity(i);

            }
        } );

    }
}
