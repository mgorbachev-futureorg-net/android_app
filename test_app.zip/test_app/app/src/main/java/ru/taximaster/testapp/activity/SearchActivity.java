/*
* Страница для отображения уменьшенных копий изображения и ввода строки для поиска по меткам
* назначенным для изображений
* */

package ru.taximaster.testapp.activity;

import android.app.ProgressDialog;
import android.graphics.drawable.BitmapDrawable;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentStatePagerAdapter;
import android.support.v4.view.PagerAdapter;
import android.support.v4.view.ViewPager;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import com.google.android.gms.maps.model.LatLng;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import ru.taximaster.testapp.R;
import ru.taximaster.testapp.dialog.ProgressDialogAnimation;

public class SearchActivity extends AppCompatActivity implements View.OnClickListener{

    static class Constants {

        public static final String TAG = "testapp";
        public static final int PAGE_COUNT = 2;
        public static final int PPP = 9;

    }


    public int page = 1;
    public Button button;
    public EditText editText;
    public static ProgressDialog pd;
    public static BitmapDrawable[] bitmaps;
    public static LatLng[] coordinates;
    public static String[] photoId;

    public ViewPager viewPager;
    public static PagerAdapter pagerAdapter;
    Handler updater;
    ArrayList<Handler> handlerList = new ArrayList<Handler>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        SearchActivity.bitmaps = new BitmapDrawable[Constants.PPP * page];
        SearchActivity.coordinates = new LatLng[Constants.PPP * page];
        SearchActivity.photoId = new String[Constants.PPP * page];



        button = (Button) findViewById(R.id.button);
        editText = (EditText) findViewById(R.id.editText);
        viewPager = (ViewPager) findViewById(R.id.viewPager);
        pagerAdapter = new MyPagerAdapter(getSupportFragmentManager());
        viewPager.setAdapter(pagerAdapter);
        viewPager.addOnPageChangeListener(new MyOnPageChangeListener());

        pd = new ProgressDialogAnimation(this);

        updater = new Handler() {
            @Override
            public void handleMessage(Message msg) {
                pagerAdapter.notifyDataSetChanged();
            }
        };

        button.setOnClickListener(this);
    }

    @Override
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.button:
                onButtonClick();
                break;
            default:
                break;
        }
    }

    public void onButtonClick() {
        button.setClickable(false);
        page = viewPager.getCurrentItem() + 1;

        SearchActivity.bitmaps = new BitmapDrawable[Constants.PPP * page];
        SearchActivity.coordinates = new LatLng[Constants.PPP * page];
        SearchActivity.photoId = new String[Constants.PPP * page];


        pd.show();

        try {
            new Thread(new Runnable() {
                @Override
                public void run() {
                    ImageLoader imageLoader = new ImageLoader();
                    imageLoader.execute(editText.getText().toString());
                    try {
                        bitmaps = imageLoader.get();
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                    pd.cancel();
                }
            }).start();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public class ImageLoader extends AsyncTask<String, Integer, BitmapDrawable[]> {
        ArrayList<String> urlList = new ArrayList<String>();
        private JSONObject respJSON;
        BitmapDrawable img = null;

        @Override
        protected BitmapDrawable[] doInBackground(String... params) {
            String[] questRaw = params[0].split(" ");
            String quest = questRaw[0];
            for (int i = 1; i < questRaw.length; i++) {
                quest = quest + "+" + questRaw[i];
            }

            String flickrKey = getResources().getString(R.string.flickr_key);

            String reqURL = "https://api.flickr.com/services/rest/?method=flickr.photos.search&api_key="
                    + flickrKey + "&sort=relevance&has_geo=1&content_type=1&per_page="
                    + (Constants.PPP * page) + "&page=1&media=photos&format=json&text='"
                    + quest + "'";

            try {
                respJSON = request2server(reqURL);
                Log.d(Constants.TAG, respJSON.toString() );

                urlList = getUrlList(respJSON);

                for (int j = 0; j < urlList.size(); j++) {

                    reqURL = "https://api.flickr.com/services/rest/?method=flickr.photos.geo.getLocation&api_key="
                            + flickrKey + "&photo_id=" + photoId[j] + "&format=json";
                    respJSON = request2server(reqURL);
                    Log.d(Constants.TAG, respJSON.toString() );

                    coordinates[j] = getCoordinates(respJSON);

                    img = getPhoto(urlList.get(j));
                    bitmaps[j] = img;
                    updater.sendEmptyMessage(0);
                    Log.d(Constants.TAG, "загружено " + (j + 1));
                    publishProgress(j);
                }

            } catch (Exception e) {
                e.printStackTrace();
            }

            return bitmaps;
        }

        @Override
        protected void onPostExecute(BitmapDrawable bitmap[]) {
            button.setClickable(true);
        }

        public JSONObject request2server(String reqURL) throws Exception {
            String jsonStr = null;
            JSONObject respJSON = null;

            try {
                URL url = new URL(reqURL);
                HttpURLConnection con = (HttpURLConnection) url.openConnection();
                con.setRequestMethod("GET");
                con.connect();

                BufferedReader reader = new BufferedReader(new InputStreamReader(con.getInputStream()));
                String line = reader.readLine();
                con.disconnect();
                reader.close();
                 // line обернуто в jsonFlickrApi(json)
                Pattern p = Pattern.compile(".*?\\((.*)\\)$");
                Matcher m = p.matcher(line);
                if (m.matches()) {
                    jsonStr = m.group(1);
                }

                respJSON = new JSONObject(jsonStr);

            } catch (Exception e) {
                e.printStackTrace();
            }

            return respJSON;
        }

        public LatLng getCoordinates(JSONObject json) {

            try {
                JSONObject location = json.getJSONObject("photo").getJSONObject("location");
                return new LatLng(location.getDouble("latitude"), location.getDouble("longitude"));

            }catch ( Exception e)
            {
                return new LatLng(0d,0d);
            }
        }

        public ArrayList<String> getUrlList(JSONObject json) {
            ArrayList<String> list = new ArrayList<String>();
            JSONArray photo = null;

            try {
                photo = json.getJSONObject("photos").getJSONArray("photo");
            } catch (Exception e) {
                e.printStackTrace();
            }

            for (int i = 0; i < photo.length(); i++) {
                try {
                    JSONObject p = photo.getJSONObject(i);
                    String farm = p.getString("farm");
                    String server = p.getString("server");
                    String id = p.getString("id");
                    String secret = p.getString("secret");
                    String url = "http://farm" + farm + ".static.flickr.com/"
                            + server + "/" + id + "_" + secret + ".jpg";
                    list.add(url);

                    photoId[i] = id;

                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }

            return list;
        }

        private BitmapDrawable getPhoto(String photoUrl) {
            BitmapDrawable img = null;
            try {
                URL url = new URL(photoUrl);
                HttpURLConnection con = (HttpURLConnection) url.openConnection();
                con.connect();
                InputStream ins = con.getInputStream();
                img = new BitmapDrawable(getResources(), ins);
                ins.close();
                con.disconnect();

            } catch (Exception e) {
                e.printStackTrace();
            }
            return img;
        }
    }

    public class MyPagerAdapter extends FragmentStatePagerAdapter {
        public MyPagerAdapter(FragmentManager fm) {
            super(fm);
        }

        @Override
        public Fragment getItem(int position) {
            SearchActivityGridFragment page = SearchActivityGridFragment.getNewInstance(position);
            handlerList.add(page.updater);
            return page;
        }

        @Override
        public int getCount() {
            return Constants.PAGE_COUNT;
        }

        @Override
        public void notifyDataSetChanged() {
            super.notifyDataSetChanged();
            for (Handler h : handlerList) {
                h.sendEmptyMessage(0);
            }
        }
    }

    class MyOnPageChangeListener implements ViewPager.OnPageChangeListener {

        @Override
        public void onPageScrolled(int position, float positionOffset, int positionOffsetPixels) {
        }

        @Override
        public void onPageSelected(int position) {
        }

        @Override
        public void onPageScrollStateChanged(int state) {
            if (state == ViewPager.SCROLL_STATE_SETTLING) {
                onButtonClick();
            }
        }
    }


}