/*
* Фрагмент страницы для отображения уменьшенных копий фотографий
* */

package ru.taximaster.testapp.activity;

import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.BitmapDrawable;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.support.v4.app.Fragment;
import android.util.AttributeSet;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.GridView;
import android.widget.ImageView;

import java.util.Random;

import ru.taximaster.testapp.R;


class GridViewSquareItem extends android.support.v7.widget.AppCompatImageView {

    public GridViewSquareItem(Context context) {
        super(context);
    }

    public GridViewSquareItem(Context context, AttributeSet attrs) {
        super(context, attrs);
    }

    public GridViewSquareItem(Context context, AttributeSet attrs, int defStyle) {
        super(context, attrs, defStyle);
    }

    @Override
    public void onMeasure(int widthMeasureSpec, int heightMeasureSpec) {
        super.onMeasure(widthMeasureSpec, widthMeasureSpec); // This is the key that will make the height equivalent to its width
    }
}

public class SearchActivityGridFragment extends Fragment {

    class Constants {
        final static String PAGE = "page";
    }

    int bkgColor;
    int page;
    public GridFragmentAdapter adapter = new GridFragmentAdapter();
    public Handler updater = new Handler() {
        @Override
        public void handleMessage(Message msg) {
            adapter.notifyDataSetChanged();
        }
    };

    public static SearchActivityGridFragment getNewInstance(int page) {
        SearchActivityGridFragment gf = new SearchActivityGridFragment();
        Bundle args = new Bundle();
        args.putInt(Constants.PAGE, page);
        gf.setArguments(args);

        return gf;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Random rnd = new Random();
        bkgColor = Color.argb(50, rnd.nextInt(256), rnd.nextInt(256), rnd.nextInt(256));
        page = getArguments().getInt(Constants.PAGE);


    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.grid_fragment, null);
        view.setBackgroundColor(bkgColor);
        ((GridView) view.findViewById(R.id.grid)).setAdapter(adapter);
        return view;
    }



    private class GridFragmentAdapter extends BaseAdapter {


        @Override
        public int getCount() {
            return SearchActivity.Constants.PPP;
        }

        @Override
        public Object getItem(int i) {
            return SearchActivity.bitmaps[i + SearchActivity.Constants.PPP * page];
        }

        @Override
        public long getItemId(int i) {
            return i + SearchActivity.Constants.PPP * page;
        }

        @Override
        public View getView(int i, View view, ViewGroup viewGroup) {
            final int ind = i + SearchActivity.Constants.PPP * page;
            ImageView v;
            if (view != null) {
                v = (GridViewSquareItem) view;
            } else {
                v = new GridViewSquareItem(getActivity());
            }
            if (SearchActivity.bitmaps != null) {
                try {
                    BitmapDrawable[] bs = SearchActivity.bitmaps;
                    BitmapDrawable b = bs[ind];
                    v.setScaleType( ImageView.ScaleType.FIT_XY);

                    if (b == null)
                    {
                        v.setImageResource(R.drawable.iv_ico);

                    }else {

                        v.setImageDrawable(b);
                    }


                } catch (Exception e) {
                    Log.e(SearchActivity.Constants.TAG, getResources().getString(R.string.log_error_show));
                }
            } else {
                v.setImageResource(R.drawable.iv_ico);
            }


            v.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    System.out.println("TEST ");

                    Intent i = new Intent(getContext(), FullImageActivity.class);
                    i.putExtra("ImageId", ind);
                    startActivity(i);
                }
            });

            return v;
        }
    }
}
